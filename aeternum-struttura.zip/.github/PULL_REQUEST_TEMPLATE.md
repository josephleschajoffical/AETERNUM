## Cosa cambia / What changes

## Perché / Why

## Come l'ho provato / How I tested

- [ ] `sh tests/check.sh` senza errori
- [ ] Commit firmati (`git commit -s`)
