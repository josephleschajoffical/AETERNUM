---
name: Proponi una funzione / Feature request
about: Un'idea per migliorare Aeternum
labels: enhancement
---

**Idea / Idea**

**Perché serve / Why**
