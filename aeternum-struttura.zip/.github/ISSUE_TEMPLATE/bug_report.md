---
name: Segnala un problema / Bug report
about: Qualcosa non funziona
labels: bug
---

**Cosa è successo / What happened**

**Cosa ti aspettavi / Expected**

**Come riprodurlo / Steps**

**Hardware o macchina virtuale / Hardware or VM**

**Versione ISO / ISO version**
